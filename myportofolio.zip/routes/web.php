<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {

    $profiles = [
        [
            "name" => "Aliffathur Risqi Hidayat",
            "position" => "Web Programmer, Graphics Designer",
            "summary" => "Saya adalah seorang Fresh-graduated S1 Informatika pada tahun 2022. Keahlian Saya berfokus pada
            Web Programming khususnya bahasa pemrograman PHP. Saya juga merupakan seorang freelancer Desain Grafis
            yang mengerjakan berbagai bentuk desain jersey, logo, poster, dsb. Saya menyukai hal-hal baru terutama
            yang mengacu pada kreativitas individu.",
            "linkedin" => "https://www.linkedin.com/in/aliffathurrisqi/",
            "github" => "https://github.com/aliffathurrisqi/",
            "instagram" => "/",
            "whatsapp" => "https://wa.me/6282322442293"
        ]
    ];

    $portofolios = [
        [
            "icon" => "bi bi-window",
            "name" => "Web Programing",
            "summary" => "Menggunakan HTML, CSS, Javascript dan PHP Saya telah membuat berbagai proyek. Memanfaatkan
            framework Bootstrap dan Laravel memaksimalkan tampilan dan fungsi pada website
            Saya telah mengerjakan proyek selama kuliah maupun secara freelancer.",
            "link" => "/"
        ],
        [
            "icon" => "bi bi-palette",
            "name" => "Graphics Design",
            "summary" => "Menggunakan perangkat lunak seperti Photoshop, Ilustrator dan Corel Draw Saya mampu
            membuat berbagai jenis desain. Selama menjadi freelancer Saya telah menyelesaikan berbagai jenis desain
            logo, jersey, poster, brosur dan masih banyak lagi",
            "link" => "/"
        ]
    ];

    $skill_languages = [
        [
            "name" => "HTML"
        ],
        [
            "name" => "CSS"
        ],
        [
            "name" => "Javascript"
        ],
        [
            "name" => "PHP"
        ],
    ];

    $skill_apps = [
        [
            "name" => "Adobe Photoshop",
            "icon" => "adobe-photoshop-white.png"
        ],
        [
            "name" => "Adobe Ilustrator",
            "icon" => "adobe-ilustrator-white.png"
        ],
        [
            "name" => "Adobe XD",
            "icon" => "adobe-xd-white.png"
        ],
        [
            "name" => "Corel Draw",
            "icon" => "corel-draw-white.png"
        ],
    ];

    $skill_tools = [
        [
            "name" => "Visual Studio Code",
            "icon" => "vscode-white.png"
        ],
        [
            "name" => "Bootstrap",
            "icon" => "bootstrap.png"
        ],
        [
            "name" => "Laravel",
            "icon" => "laravel.png"
        ],
    ];

    return view(
        'index',
        [
            "title" => "Home",
            "profiles" => $profiles,
            "portofolios" => $portofolios,
            "skill_languages" => $skill_languages,
            "skill_apps" => $skill_apps,
            "skill_tools" => $skill_tools,
        ]
    );
});

Route::get('/about', function () {
    return view(
        'about',
        ["title" => "About"]
    );
});

Route::get('/portfolio/website', function () {

    $portfolios = [
        [
            "name" => "Lobby Forum",
            "keterangan" => "Website Forum Diskusi Mobile Legends",
            "build" => "HTML, PHP, Javascript, Bootstrap",
            "link" => "https://lobby.alfaristudio.my.id/login.php"
        ],
        [
            "name" => "Beautyfinder",
            "keterangan" => "Webview Pencarian Toko Kebutuhan Wanita di Yogyakarta",
            "build" => "HTML, PHP, Javascript, Bootstrap, Google Map API, Kotlin, Android Studio",
            "link" => "https://beautyfinder.alfaristudio.my.id/login.php"
        ],
    ];

    return view(
        'portfolio_web',
        ["title" => "Website Portfolio"]
    );
});
